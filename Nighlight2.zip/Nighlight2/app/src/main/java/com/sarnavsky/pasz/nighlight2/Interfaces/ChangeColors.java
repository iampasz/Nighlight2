package com.sarnavsky.pasz.nighlight2.Interfaces;

public interface ChangeColors {

    public void onclick(int button);

}
