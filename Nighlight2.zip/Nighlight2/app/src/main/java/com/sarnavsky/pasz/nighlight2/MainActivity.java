package com.sarnavsky.pasz.nighlight2;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentManager;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.sarnavsky.pasz.nighlight2.Fragments.MainFragment;
import com.sarnavsky.pasz.nighlight2.Models.Nightlight;

import fr.nicolaspomepuy.discreetapprate.AppRate;
import io.realm.Realm;
import io.realm.RealmResults;

//import com.facebook.appevents.AppEventsConstants;

public class MainActivity extends AppCompatActivity {
    FragmentManager fm;
    private static final String TAG = "MainActivity";
    private static final String MY_SETTINGS = "my_settings";
    Realm realm;
    ConstraintLayout adContainerView;
    AdView mAdView;

    int wrapContent = LinearLayout.LayoutParams.MATCH_PARENT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Realm.init(this);
        realm = Realm.getDefaultInstance();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setContentView(R.layout.main);
        fm = getSupportFragmentManager();
        //FrameLayout container = (FrameLayout) ColorController()
        fm.beginTransaction().add(R.id.container, new MainFragment(), "main_fragment").commit();

        // Initialize the Mobile Ads SDK.
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) { }
        });

        adContainerView = findViewById(R.id.constrain);
        // Step 1 - Create an AdView and set the ad unit ID on it.
        mAdView = new AdView(this);
        //mAdView.setAdUnitId(getString(R.string.banner_ad_unit_id));

         mAdView.setId(R.id.ads);
        mAdView.setAdUnitId(getString(R.string.banner_ad_unit_id));
        //mAdView.setAdUnitId("ca-app-pub-3940256099942544/9214589741");
        adContainerView.addView(mAdView);
        loadBanner();

        AppRate.with(MainActivity.this).initialLaunchCount(2).checkAndShow();
        SharedPreferences sp = getSharedPreferences(MY_SETTINGS,
                Context.MODE_PRIVATE);
        // проверяем, первый ли раз открывается программа
        boolean hasVisited = sp.getBoolean("hasVisited", false);

        if (!hasVisited) {
            // выводим нужную активность
            SharedPreferences.Editor e = sp.edit();
            e.putBoolean("hasVisited", true);
            e.commit(); // не забудьте подтвердить изменения

            addToReallm();
        }
    }

    private void loadBanner() {
//        AdRequest adRequest = new AdRequest.Builder().addTestDevice ("DF666E0D371B0FD388029A01F5323F05").addTestDevice("4642B5D65FCEE3D701A93A8A6ED589EA")
//                .build();
//        AdSize adSize = getAdSize();
//        mAdView.setAdSize(adSize);
//        mAdView.loadAd(adRequest);
    }

    private AdSize getAdSize() {
        // Step 2 - Determine the screen width (less decorations) to use for the ad width.
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float widthPixels = outMetrics.widthPixels;
        float density = outMetrics.density;

        int adWidth = (int) (widthPixels / density);

        // Step 3 - Get adaptive ad size and return for setting on the ad view.
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }

    private void toster(String tost){
        Toast.makeText(this, tost, Toast.LENGTH_SHORT).show();
    }

    private void addToReallm(){
        realm.beginTransaction();
        for(int i =400; i<=600; i++){
            Nightlight nightlights = realm.createObject(Nightlight.class); // Create managed objects directly
            nightlights.setNumber(i);
            nightlights.setTimer(60000);
        }
        realm.commitTransaction();
        RealmResults<Nightlight> realmResults = realm.where(Nightlight.class).findAll();
        //Toast.makeText(this, "Первый запуск"+realm.where(Nightlight.class).findAll().size(), Toast.LENGTH_LONG).show();
    }

    public static boolean hasConnection(final Context context)
    {
        ConnectivityManager cm = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo wifiInfo = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        if (wifiInfo != null && wifiInfo.isConnected())
        {
            return true;
        }
        wifiInfo = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        if (wifiInfo != null && wifiInfo.isConnected())
        {
            return true;
        }
        wifiInfo = cm.getActiveNetworkInfo();
        if (wifiInfo != null && wifiInfo.isConnected())
        {
            return true;
        }
        return false;
    }
}
