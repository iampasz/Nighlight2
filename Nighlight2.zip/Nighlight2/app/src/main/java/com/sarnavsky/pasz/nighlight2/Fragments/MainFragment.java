package com.sarnavsky.pasz.nighlight2.Fragments;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.sarnavsky.pasz.nighlight2.Adapters.MyPagerAdapter;
import com.sarnavsky.pasz.nighlight2.Adapters.RecyclerViewAdapter;
import com.sarnavsky.pasz.nighlight2.Fabrica.MyMenuItems;
import com.sarnavsky.pasz.nighlight2.Interfaces.ChangeColors;
import com.sarnavsky.pasz.nighlight2.Objects.MenuButton;
import com.sarnavsky.pasz.nighlight2.R;

import java.util.ArrayList;
import java.util.Random;

import io.realm.Realm;

public class MainFragment extends Fragment {

    ViewPager pager;
    MyPagerAdapter pagerAdapter;
    MediaPlayer mediaPlayer;
    FrameLayout mainBg;
    RecyclerViewAdapter adapter;
    LinearLayout lockButton;
    RecyclerView rv;
    ImageView lock_button;
    FrameLayout lock_frame;
    ImageView animateBg, presents;
    CountDownTimer timerOff;
    Boolean show = true;
   // Boolean rewardShow = true;

    private InterstitialAd mInterstitialAd;

   // private RewardedVideoAd mRewardedVideoAd;

    AdView adView;

    private static final int EMPTY_SOUND = 7;
    private static final int FIRST_SOUND = 8;
    private static final int SECOND_SOUND = 9;

    private static final int RED_COLOR = 10;
    private static final int WHITE_COLOR = 11;
    private static final int BLACK_COLOR = 12;

    private static final int ORANGE_COLOR = 13;
    private static final int YELLOW_COLOR = 14;
    private static final int GREEN_COLOR = 15;
    private static final int CANYAN_COLOR = 16;
    private static final int BLUE_COLOR = 17;
    private static final int MOOD_COLOR = 18;

    Context ctx;
    MyMenuItems menuItems;
    boolean chekMenu = true;

    String[] colors;
    String[] bgColors;
    String[] bgNlColors;
    String[] menuColors;

    int sound = 0;
    int color = 0;
    int bg_color = 0;
    int anim_bg = 0;
    int brights = 0;
    int timer = 0;
    CountDownTimer countDownTimer;


   ImageView imageView;
    Realm realm;
    boolean showed;
    boolean chekAnim =false;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.main_fragment, null);

    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onViewCreated(final View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        ctx = view.getContext();

        FragmentActivity main = getActivity();

        adView = (AdView) main.findViewById(R.id.ads);


        Log.i("TAG", "");

        countDownTimer = new CountDownTimer(5000, 5000) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                lockButton.setVisibility(View.GONE);
                rv.setVisibility(View.GONE);

            }
        }.start();


        mainBg = (FrameLayout) view.findViewById(R.id.mainBg);
        pager = (ViewPager) view.findViewById(R.id.pager);
        menuItems = new MyMenuItems();
        pagerAdapter = new MyPagerAdapter(getFragmentManager(), menuItems.getNightlighters());
        lockButton = (LinearLayout) view.findViewById(R.id.lockButton);
        lock_button = (ImageView) view.findViewById(R.id.lock_button);
        presents = (ImageView) view.findViewById(R.id.presents);
        animateBg = (ImageView) view.findViewById(R.id.animateBg);
        pager.setAdapter(pagerAdapter);
        pager.setCurrentItem(500);
        rv = (RecyclerView) view.findViewById(R.id.rv);
        LinearLayoutManager llm = new LinearLayoutManager(view.getContext(), LinearLayoutManager.HORIZONTAL, false);
        rv.setLayoutManager(llm);
        Resources res = getResources();
        colors = res.getStringArray(R.array.myColors);
        bgColors = res.getStringArray(R.array.bgColors);
        bgNlColors = res.getStringArray(R.array.bgNlColors);
        menuColors = res.getStringArray(R.array.menuColors);
        lock_frame = (FrameLayout) view.findViewById(R.id.lock_frame);


        lock_frame.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) { lockFrame(); return false;
            }
        });


        lockButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { lockButton(); } });



        Realm.init(ctx);

       realm = Realm.getDefaultInstance();

       presents.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
//
//               if (mRewardedVideoAd.isLoaded()) {
//                   mRewardedVideoAd.show();
//               }
//               loadRewardedVideoAd();
           }
       });



       pager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
           @Override
           public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

               //Log.d("TAG", positionOffset+" position ofset " + position+" ositio  " + positionOffsetPixels+" pixel ");

           }

           @Override
           public void onPageSelected(int position) {

               if((position>500 || position<500) && !showed) {
                   //showAd();
               }
               randomColor();
           }

           @Override
           public void onPageScrollStateChanged(int state) {

           }
       });

        //MobileAds.initialize(ctx,
              //  "ca-app-pub-1657105281106558~4967121964");
               // "ca-app-pub-1237459888817948~7720722245");
        //мой банер
              //  "ca-app-pub-1237459888817948~7720722245");
        //Банер егора тот что заблокировали после удалегнния ночника
               // "ca-app-pub-1657105281106558~4967121964");

    //    mInterstitialAd = new InterstitialAd(ctx);
        //Банер егора тот что заблокировали после удалегнния ночника
        //mInterstitialAd.setAdUnitId("ca-app-pub-1657105281106558/1776851768");
        //мой банер
       // mInterstitialAd.setAdUnitId("ca-app-pub-1237459888817948/9922711695");
        // Мой банер межстраничний
    //    mInterstitialAd.setAdUnitId("ca-app-pub-1237459888817948/2410476190");
        //тестовый баннер
     //   mInterstitialAd.setAdUnitId("ca-app-pub-3940256099942544/6300978111");
//        mInterstitialAd.setAdUnitId("ca-app-pub-1657105281106558/1776851768");
//        mInterstitialAd.loadAd(new AdRequest.Builder().build());
//
//        mRewardedVideoAd = MobileAds.getRewardedVideoAdInstance(ctx);
//        mRewardedVideoAd.setRewardedVideoAdListener(new RewardedVideoAdListener() {
//            @Override
//            public void onRewardedVideoAdLoaded() {
//                if(chekMenu){
//                   // presents.setVisibility(View.VISIBLE);
//                }
//               // rewardShow=false;
//            }
//            @Override
//            public void onRewardedVideoAdOpened() {
//            }
//            @Override
//            public void onRewardedVideoStarted() {
//            }
//            @Override
//            public void onRewardedVideoAdClosed() {
//                //loadRewardedVideoAd();
//                //rewardShow=true;
//                //presents.setVisibility(View.GONE);
//            }
//            @Override
//            public void onRewarded(RewardItem rewardItem) {
//                showAlertDialog(R.string.title_ad, R.string.text_ad, R.drawable.congratulations);
//                Fragment myFragment = getFragmentManager().findFragmentByTag("myFragment" + pager.getCurrentItem());
//                ImageView underImageView = myFragment.getView().findViewById(R.id.underImg);
//                ImageView upImageView = myFragment.getView().findViewById(R.id.upImg);
//                underImageView.setImageResource(R.drawable.moon2);
//                upImageView.setImageResource(R.drawable.moon1);
//                TextView textView = myFragment.getView().findViewById(R.id.nameNightlight);
//                textView.setText(R.string.moon);
//            }
//            @Override
//            public void onRewardedVideoAdLeftApplication() {
//            }
//            @Override
//            public void onRewardedVideoAdFailedToLoad(int i) {
//            }
//            @Override
//            public void onRewardedVideoCompleted() {
//            }
//        });
       // loadRewardedVideoAd();

        openMenu(menuItems.getMenuButtons(colors));
      //  }
    }

//    private void loadRewardedVideoAd() {
//       // mRewardedVideoAd.loadAd("ca-app-pub-1657105281106558/1676050463",
//        //мой баннер за ревард
//        mRewardedVideoAd.loadAd("ca-app-pub-1237459888817948/1227873573",
//                new AdRequest.Builder().addTestDevice ("DF666E0D371B0FD388029A01F5323F05").addTestDevice ("4642B5D65FCEE3D701A93A8A6ED589EA").build());
//    }

    public void openMenu(ArrayList<MenuButton> menuButtons) {

        adapter = new RecyclerViewAdapter(menuButtons, menuColors);

        adapter.MyOnclick(new ChangeColors() {
            @Override
            public void onclick(int button) {
                switch (button) {
                    case 1:
                        playSound();
                        break;
                    case 2:
                        showBgColorMenu();
                        break;
                    case 3:
                        showBgNlMenu();
                        break;
                    case 4:
                        startAnimation();

                        break;
                    case 6:
                        switch (anim_bg) {

                            case 0:
                                animateBg.setImageResource(R.drawable.blue_bg);
                                anim_bg ++;
                                break;
                            case 1:
                                animateBg.setImageResource(R.drawable.animal_bg);
                                anim_bg++;
                                break;
                            case 2:
                                animateBg.setImageResource(R.drawable.first_bg);
                                anim_bg++;
                                break;
                            case 3:
                                animateBg.setImageResource(R.drawable.flowers_bg);
                                anim_bg++;
                                break;
                            case 4:
                                animateBg.setImageResource(R.drawable.bloo);
                                anim_bg++;
                                break;
                            case 5:
                                animateBg.setImageResource(R.drawable.green_bg);
                                anim_bg++;
                                break;
                            case 6:
                                animateBg.setImageResource(R.drawable.green2_bg);

                                anim_bg++;
                                break;
                            case 7:
                                animateBg.setImageResource(R.drawable.star2);

                                anim_bg++;
                                break;

                            case 8:
                                animateBg.setImageResource(0);

                                anim_bg=0;
                                break;

                        }
                        break;
                    case 5:
                        int time;
                        switch (timer){
                            case 0:
                                time = 1000*10*60;
                                showToastFragment(R.drawable.ic_time, "00:10");
                                startOffTimer(time);
                                timer++;
                                break;
                            case 1:
                                time = 1000*30*60;
                                showToastFragment(R.drawable.ic_time, "00:30");
                                startOffTimer(time);
                                timer++;
                                break;
                            case 2:
                                time = 1000*60*60;
                                showToastFragment(R.drawable.ic_time, "01:00");
                                startOffTimer(time);
                                timer++;
                                break;
                            case 3:
                                showToastFragment(R.drawable.ic_time, "Off");
                                timer=0;
                                if(timerOff!=null ){
                                    timerOff.cancel();
                                }
                                break;
                        }
                        break;
                    case 7:
                        changeBrighest();
                        break;
                    case 8:
                        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://paszzsap.github.io/nightlight2/politic.html"));
                        startActivity(browserIntent);
                        break;
                }
            }


        });
        rv.setAdapter(adapter);
    }

    private void playSound() {

        if (mediaPlayer != null) {
            mediaPlayer.pause();
            mediaPlayer.reset();
            mediaPlayer = null;
        }

        switch (sound) {
            case 0:

                if (mediaPlayer != null) {
                    mediaPlayer.release();
                    mediaPlayer = null;
                }
                mediaPlayer = MediaPlayer.create(ctx,
                        R.raw.detskaya);
                mediaPlayer.setLooping(true);
                mediaPlayer.start();
                sound++;
                showToastFragment(R.drawable.sounds, "melody1");

                break;

            case 1:

                if (mediaPlayer != null) {
                    mediaPlayer.release();
                    mediaPlayer = null;
                }
                mediaPlayer = MediaPlayer.create(ctx,
                        R.raw.sound);
                mediaPlayer.setLooping(true);
                mediaPlayer.start();
                sound++;
                showToastFragment(R.drawable.sounds, "Silence");

                break;
            case 2:
                if (mediaPlayer != null) {
                    mediaPlayer.release();
                    mediaPlayer = null;
                }
                mediaPlayer = MediaPlayer.create(ctx,
                        R.raw.eho);
                mediaPlayer.setLooping(true);
                mediaPlayer.start();
                sound++;
                showToastFragment(R.drawable.sounds, "Night");

                break;

            case 3:
                if (mediaPlayer != null) {
                    mediaPlayer.release();
                    mediaPlayer = null;
                }
                mediaPlayer = MediaPlayer.create(ctx,
                        R.raw.nostalgi);
                mediaPlayer.setLooping(true);
                mediaPlayer.start();
                sound++;
                showToastFragment(R.drawable.sounds, "Spring");
                break;
            case 4:
                if (mediaPlayer != null) {
                    mediaPlayer.release();
                    mediaPlayer = null;
                }
                sound = 0;
                showToastFragment(R.drawable.sounds, "Winter");
                break;
        }
    }

    private void showBgColorMenu() {
        switch (bg_color) {
            case 0:
                mainBg.setBackgroundColor(Color.parseColor(bgColors[0]));
                bg_color++;
                break;
            case 1:
                mainBg.setBackgroundColor(Color.parseColor(bgColors[1]));
                bg_color++;
                break;
            case 2:
                mainBg.setBackgroundColor(Color.parseColor(bgColors[2]));
                bg_color++;
                break;
            case 3:
                mainBg.setBackgroundColor(Color.parseColor(bgColors[3]));
                bg_color++;
                break;
            case 4:
                mainBg.setBackgroundColor(Color.parseColor(bgColors[4]));
                bg_color++;
                break;
            case 5:
                mainBg.setBackgroundColor(Color.parseColor(bgColors[5]));
                bg_color++;
                break;
            case 6:
                mainBg.setBackgroundColor(Color.parseColor(bgColors[6]));
                bg_color++;
                break;
            case 7:
                mainBg.setBackgroundColor(Color.parseColor(bgColors[7]));
                bg_color ++;
                break;
            case 8:
                mainBg.setBackgroundColor(Color.parseColor(bgColors[8]));
                bg_color ++;
                break;
            case 9:
                mainBg.setBackgroundColor(Color.parseColor(bgColors[9]));
                bg_color = 0;
                break;
        }
    }

    private void showBgNlMenu() {
        Fragment myFragment = getFragmentManager().findFragmentByTag("myFragment" + pager.getCurrentItem());
        imageView = myFragment.getView().findViewById(R.id.underImg);
        switch (color) {
            case 0:
                imageView.setColorFilter(Color.parseColor(bgNlColors[0]));
                color++;
                break;
            case 1:
                imageView.setColorFilter(Color.parseColor(bgNlColors[1]));
                color++;
                break;
            case 2:
                imageView.setColorFilter(Color.parseColor(bgNlColors[2]));
                color++;
                break;
            case 3:
                imageView.setColorFilter(Color.parseColor(bgNlColors[3]));
                color++;
                break;
            case 4:
                imageView.setColorFilter(Color.parseColor(bgNlColors[4]));
                color++;
                break;
            case 5:
                imageView.setColorFilter(Color.parseColor(bgNlColors[5]));
                color++;
                break;
            case 6:
                imageView.setColorFilter(Color.parseColor(bgNlColors[6]));
                color++;
                break;
            case 7:
                imageView.setColorFilter(Color.parseColor(bgNlColors[7]));
                color++;
                break;
            case 8:
                imageView.setColorFilter(Color.parseColor(bgNlColors[8]));
                color++;
                break;
            case 9:
                imageView.setColorFilter(Color.parseColor(bgNlColors[9]));
                color++;
                break;
            case 10:
                imageView.setColorFilter(Color.parseColor(bgNlColors[10]));
                color++;
                break;
            case 11:
                imageView.setColorFilter(Color.parseColor(bgNlColors[11]));
                color=0;
                break;
        }
    }

    public void showToastFragment(int image, String text){
         final Fragment fragment = ToastFragment.init(image, text);
        getFragmentManager().beginTransaction().add(R.id.container, fragment, "toast_frag").commit();

       CountDownTimer cdt = new CountDownTimer(2000, 2000) {
            @Override
            public void onTick(long millisUntilFinished) {
            }

            @Override
            public void onFinish() {
               getFragmentManager().beginTransaction().remove(fragment).commit();
            }
        }.start();
    }

    public void changeBrighest(){
        WindowManager.LayoutParams layout = getActivity().getWindow().getAttributes();

        switch (brights){
            case 0:
                //showToastFragment(R.drawable.ic_light, "10%");
                layout.screenBrightness = 0.1F;

                brights++;
                break;
            case 1:
                //showToastFragment(R.drawable.ic_light, "50%");
                layout.screenBrightness = 0.5F;

                brights++;
                break;
            case 2:
                //showToastFragment(R.drawable.ic_light, "100%");
                layout.screenBrightness = 1F;

                brights=0;
                break;

        }

        getActivity().getWindow().setAttributes(layout);
    }

    @Override
    public void onStop() {
        super.onStop();
//        if (mediaPlayer != null) {
//            //mediaPlayer.pause();
//            //mediaPlayer = null;
//        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.reset();
            mediaPlayer.stop();
            mediaPlayer = null;
        }

      //  mRewardedVideoAd.destroy(ctx);
    }

    @Override
    public void onResume() {
        super.onResume();
//        if (mediaPlayer != null) {
//            mediaPlayer.start();
//            mediaPlayer = null;
//
//            adapter.notifyDataSetChanged();
//        }

      //  mRewardedVideoAd.resume(ctx);
    }

    public void startAnimation(){

if(chekAnim==false) {
    RotateAnimation rotate = new RotateAnimation(0f, 360f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f); //8
    rotate.setDuration(100000);
    rotate.setRepeatCount(Animation.INFINITE);
    rotate.setInterpolator(new LinearInterpolator());
    AnimationSet set = new AnimationSet(false); //10
    set.addAnimation(rotate);
    animateBg.startAnimation(set);
    chekAnim=true;

    ScaleAnimation scale = new ScaleAnimation(1f, 1f, 2f, 2f);
    scale.setDuration(1000);
    animateBg.startAnimation(scale);

    Animation animation = AnimationUtils.loadAnimation(getContext(), R.anim.rotate);
    animation.setRepeatCount(Animation.INFINITE);
    animateBg.startAnimation(animation);


}else {
    animateBg.clearAnimation();
    chekAnim=false;
}

    }

    public void startOffTimer(int time){

        if(timerOff!=null ){
            timerOff.cancel();
        }

        timerOff = new CountDownTimer(time,1000) {
            @Override
            public void onTick(long millisUntilFinished) {
            }
            @Override
            public void onFinish() {
                getActivity().finish();
            }
        }.start();
    }

    public void changeRandomColor(){

        Random random = new Random();
        int NLRColor = random.nextInt(8);
        int BGNLRColor = random.nextInt(8);

        Fragment myFragment = getFragmentManager().findFragmentByTag("myFragment" + pager.getCurrentItem());

       // Toast.makeText(ctx, myFragment+"iimi", Toast.LENGTH_SHORT).show();
       // imageView = myFragment.getView().findViewById(R.id.underImg);

        mainBg.setBackgroundColor(Color.parseColor(bgColors[BGNLRColor]));
        //imageView.setColorFilter(Color.parseColor(bgNlColors[NLRColor]));

    }

    public void lockButton(){

        Fragment myFragment = getFragmentManager().findFragmentByTag("myFragment" + pager.getCurrentItem());
        final TextView textView = myFragment.getView().findViewById(R.id.nameNightlight);

        if (chekMenu) {
            openMenu(menuItems.getMenuButtons(colors));
            rv.setVisibility(View.INVISIBLE);
            textView.setVisibility(View.GONE);
            lock_button.setImageResource(R.drawable.ic_lock);
            adView.setVisibility(View.INVISIBLE);

            //presents.setVisibility(View.INVISIBLE);
            lock_frame.setClickable(true);
            chekMenu = false;
            show = false;
        } else {
           // rv.removeAllViews();
            rv.setVisibility(View.VISIBLE);
            textView.setVisibility(View.VISIBLE);
            lock_button.setImageResource(R.drawable.ic_unlock);
            adView.setVisibility(View.VISIBLE);


           // presents.setVisibility(View.VISIBLE);


            lock_frame.setClickable(false);
            chekMenu = true;
            show = true;
        }

    }

    private void menuButton(){

//        if (chekMenu) {
//            openMenu(menuItems.getMenuButtons(colors));
//            rv.setVisibility(View.VISIBLE);
//            chekMenu = false;
//        } else {
//            rv.removeAllViews();
//            rv.setVisibility(View.INVISIBLE);
//            chekMenu = true;
//        }
    }

    private void lockFrame(){
        if(chekMenu){
            rv.setVisibility(View.VISIBLE);
        }
        lockButton.setVisibility(View.VISIBLE);
        countDownTimer.start();
    }


    private void showAd(){

        new AlertDialog.Builder(ctx)
                .setTitle("Open Nightlight")
                .setMessage("Open nightlight for advertising")
                .setIcon(R.drawable.ads)
                .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

//                        if (mInterstitialAd.isLoaded()) {
//                            mInterstitialAd.show();
//                        } else {
//                            Log.d("TAG", "The interstitial wasn't loaded yet.");
//                        }

                        showed=true;
                    }
                })
                .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        pager.setCurrentItem(500);
                    }
                })
                .setCancelable(true)
                .setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialogInterface) {
                        pager.setCurrentItem(500);
                    }
                })
                .show();

    }

    @Override
    public void onPause() {
       // mRewardedVideoAd.pause(ctx
     //   );
        super.onPause();
    }

    public void showAlertDialog(int title, int message, int icon ){

        new AlertDialog.Builder(ctx)
                .setTitle(title)
                .setMessage(message)
                .setIcon(icon)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {


                    }
                })
                .show();

    }

    public void randomColor(){

        int intColor;

        Fragment myFragment = getFragmentManager().findFragmentByTag("myFragment" + pager.getCurrentItem());
        imageView = myFragment.getView().findViewById(R.id.underImg);

        Random random = new Random();

        intColor = random.nextInt(bgNlColors.length);
                imageView.setColorFilter(Color.parseColor(bgNlColors[intColor]));



    }

}
