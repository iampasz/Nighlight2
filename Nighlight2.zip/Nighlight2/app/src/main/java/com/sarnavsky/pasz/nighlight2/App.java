package com.sarnavsky.pasz.nighlight2;

import androidx.multidex.MultiDexApplication;

import io.realm.Realm;

public class App extends MultiDexApplication {

    @Override
    public void onCreate() {
        super.onCreate();

        Realm.init(this);
         Realm realm = Realm.getDefaultInstance();

    }
}
